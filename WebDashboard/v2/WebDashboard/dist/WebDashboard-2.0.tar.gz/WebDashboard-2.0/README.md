# v2 Tasks
 - Create interactive browers based button
 - Change inventory variable on button press