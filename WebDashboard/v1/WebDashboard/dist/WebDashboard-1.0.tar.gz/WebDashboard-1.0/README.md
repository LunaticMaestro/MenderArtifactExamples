# v1 Tasks
 - Create a Dash app in python
 - Wrap the app as pyhton package and deploy as single file
 - Create the state-scripts 
   - to install the previous deploy package
   - Make the package run as service in ubuntu